Note
====

Responsive Mobile First Web Template 
Author URI: http://lalojuar3z.com/
Description: Ace is a responsive coming soon template, It is lightweight template comes with image slideshow background overlay pattern.
License: Free to use for personal and commercial, but you need to place back link in the bottom of the template(Template by: lalojuar3z.com).


Credits
=======
Slider - http://lalojuar3z.com/

	